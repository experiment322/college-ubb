package factory;

public enum Strategy {
    LIFO, FIFO;
}
