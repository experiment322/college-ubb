package factory;

import factory.Factory;
import factory.Strategy;
import model.Container;
import model.StackContainer;

public class TaskContainerFactory implements Factory {
    @Override
    public Container createContainer(Strategy startegy) {
        if (startegy==Strategy.FIFO)
            return null;//Pe vitor vom returna new queueContainer
        else
            return new StackContainer();
    }
}
