#pragma once

void runMedicineServiceTests();