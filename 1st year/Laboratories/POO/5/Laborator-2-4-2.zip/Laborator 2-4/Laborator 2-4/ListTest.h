#pragma once
typedef struct {
	int x;
	int y;
} TestStruct;

void runListTests();