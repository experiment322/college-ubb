#pragma once
typedef struct {
	int x;
	int y;
} UtilsStruct;

void runUtilsTest();