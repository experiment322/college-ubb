#pragma once

#include <assert.h>
#include <stddef.h>
#include "Medicine/Medicine.h"

void runDomainTests();